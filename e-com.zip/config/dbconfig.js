module.exports = {
    url: "mongodb+srv://dbUser:mydb@cluster0.sljlx.mongodb.net/E-Com?retryWrites=true&w=majority"
    };

    //username : dbUser
    //password:mydb
    //database name : myDatabase